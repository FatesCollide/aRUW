package aRUW;

import java.util.ArrayList;
import java.util.List;

//Parses incoming words into messages according to the defined protocol
public class MessageParser {
 private static final int WHEEL_VELOCITY_MESSAGE_TYPE = 1;
 private static final int VISION_TARGET_MESSAGE_TYPE = 2;

 private int messageType; // Type of the current message being processed
 private List<Integer> currentMessageData; // Data of the current message being processed
 private List<WheelVelocityMessage> wheelMessages; // List of parsed wheel velocity messages
 private List<VisionTargetMessage> visionMessages; // List of parsed vision target messages
 private int numTargets; // Number of targets in the current vision target message being processed

 // Constructor to initialize the parser and message lists
 public MessageParser() {
     wheelMessages = new ArrayList<>();
     visionMessages = new ArrayList<>();
     resetMessage(); // Initialize message state
 }

 // Processes a new word and constructs messages based on the protocol
 public void processNewWord(int word) {
     if (messageType == 0) { // Start of a new message
         messageType = word;
         currentMessageData = new ArrayList<>();
     } else { // Continue processing the current message
         currentMessageData.add(word);
         if (messageType == WHEEL_VELOCITY_MESSAGE_TYPE && currentMessageData.size() == 2) {
             // Construct and add a new wheel velocity message
             wheelMessages.add(new WheelVelocityMessage(currentMessageData.get(0), currentMessageData.get(1)));
             resetMessage(); // Reset message state
         } else if (messageType == VISION_TARGET_MESSAGE_TYPE) {
             if (currentMessageData.size() == 1) {
                 numTargets = word; // Set the number of targets
             } else if (currentMessageData.size() == numTargets * 2 + 1) {
                 // Construct and add a new vision target message
                 int[] xCoordinates = new int[numTargets];
                 int[] yCoordinates = new int[numTargets];
                 for (int i = 0; i < numTargets; i++) {
                     xCoordinates[i] = currentMessageData.get(i + 1);
                     yCoordinates[i] = currentMessageData.get(i + numTargets + 1);
                 }
                 visionMessages.add(new VisionTargetMessage(numTargets, xCoordinates, yCoordinates));
                 resetMessage(); // Reset message state
             }
         }
     }
 }

 // Resets the message state after processing a complete message
 private void resetMessage() {
     messageType = 0;
     if (currentMessageData != null) {
         currentMessageData.clear();
     }
 }

 // Returns the list of parsed wheel velocity messages
 public List<WheelVelocityMessage> getWheelVelocityMessages() {
     return wheelMessages;
 }

 // Returns the list of parsed vision target messages
 public List<VisionTargetMessage> getVisionTargetMessages() {
     return visionMessages;
 }
}