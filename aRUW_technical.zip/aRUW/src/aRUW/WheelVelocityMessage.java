package aRUW;

//Represents a message containing wheel velocity information
public class WheelVelocityMessage {
 int leftSpeed; // Left wheel speed in millimeters per second
 int rightSpeed; // Right wheel speed in millimeters per second

 // Constructor to initialize leftSpeed and rightSpeed
 WheelVelocityMessage(int leftSpeed, int rightSpeed) {
     this.leftSpeed = leftSpeed;
     this.rightSpeed = rightSpeed;
 }
}