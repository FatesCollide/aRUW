package aRUW;

import java.util.List;

//Main class to simulate incoming messages and print parsed messages
public class Main {
 public static void main(String[] args) {
     MessageParser parser = new MessageParser();
     int[] words = {1, 100, 200, 2, 4, 10, 20, 30, 40, 50, 90, 20, 30 };

     // Process each word and simulate incoming messages
     for (int word : words) {
         parser.processNewWord(word);
     }

     // Retrieve parsed wheel velocity and vision target messages
     List<WheelVelocityMessage> wheelMessages = parser.getWheelVelocityMessages();
     List<VisionTargetMessage> visionMessages = parser.getVisionTargetMessages();

     // Print parsed wheel velocity messages
     for (WheelVelocityMessage message : wheelMessages) {
         System.out.println("Wheel Velocity Message:");
         System.out.println("Left Speed: " + message.leftSpeed + " mm/s");
         System.out.println("Right Speed: " + message.rightSpeed + " mm/s");
     }

     // Print parsed vision target messages
     for (VisionTargetMessage message : visionMessages) {
         System.out.println("Vision Target Message:");
         System.out.println("Number of Targets: " + message.numTargets);
         for (int i = 0; i < message.numTargets; i++) {
             System.out.println("Target " + (i + 1) + " - X: " + message.xCoordinates[i] + " Y: "
                     + message.yCoordinates[i]);
         }
     }
 }
}