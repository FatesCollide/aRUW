package aRUW;

public class VisionTargetMessage {
    int numTargets; // Number of targets detected
    int[] xCoordinates; // X coordinates of detected targets
    int[] yCoordinates; // Y coordinates of detected targets

    // Constructor to initialize numTargets, xCoordinates, and yCoordinates
    VisionTargetMessage(int numTargets, int[] xCoordinates, int[] yCoordinates) {
        this.numTargets = numTargets;
        this.xCoordinates = xCoordinates;
        this.yCoordinates = yCoordinates;
    }
}
